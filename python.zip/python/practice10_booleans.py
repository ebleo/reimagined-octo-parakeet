# -*- coding: utf-8 -*-
"""
Created on Tue Nov 15 16:38:29 2016

@author: danielle.leong
"""

name = input("What is your name? ")
password = input("Enter your password: ")

atmp = 1 # first attempt above
exit = False

while atmp < 3 and exit != True:
    if name == "Josh" and password == "Friday":
        print("Heya Josh!")
        exit = True
    elif name == "Fred" and password == "Unicorn":
        print("Sup Fred!")
        exit = True
    else:
        print("Iunno ya buddy.")
        print("Try again")
        name = input("What is your name? ")
        password = input("Enter your password: ")
        atmp = atmp + 1
        if atmp == 3:
            print("You're out of luck!")
