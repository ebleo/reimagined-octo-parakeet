# -*- coding: utf-8 -*-
"""
Created on Tue Nov  8 15:29:42 2016

@author: danielle.leong
"""

print("please wokr")