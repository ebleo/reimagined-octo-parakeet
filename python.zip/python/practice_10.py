# Tutorial for Python 3/Boolean expressions
# https://en.wikibooks.org/wiki/Non-Programmer%27s_Tutorial_for_Python_3/Boolean_Expressions
# Boolean Expressions
#------------------------------
## example
list = ["Life", "The Universe", "Everything", "Jack", "Jill", "life", "Jill"]

copy = list[:]
copy.sort()
prev = copy[0]
del copy[0]

count = 0

while count < len(copy) and copy[count] != prev:
    prev = copy[count]
    count = count + 1

if count <len(copy): # if no match is found, count !< len(copy)
    print("First Match: ", prev)
