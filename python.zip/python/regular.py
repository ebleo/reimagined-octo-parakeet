# -*- coding: utf-8 -*-
"""
Created on Thu Nov 17 14:49:36 2016

@author: danielle.leong
"""

# https://developers.google.com/edu/python/regular-expressions

import re

ste = 'an example world:cat!!'
match = re.search(r'word:\w\w\w', str)

if match:
    print('found', match.group())
else:
    print('did not find')
