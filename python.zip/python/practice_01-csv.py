# -*- coding: utf-8 -*-
"""
Created on Tue Nov  8 15:50:10 2016

@author: danielle.leong
"""

# must load in some csv file
# file duplicated loaded in rel path \python
