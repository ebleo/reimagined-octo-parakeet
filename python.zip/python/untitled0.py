# -*- coding: utf-8 -*-
"""
Created on Wed Nov 16 13:56:27 2016

@author: danielle.leong
"""

import numpy as np

y = []
bins = [1, 2, 3, 4, 5] 
t = [0,0,0,0,0]

for i in range(len(bins)):
    bins[i] = bins[i] / 5

for i in range(1000):
    x = np.random.random()
    y.append(x)
    if x < bins[0]:
        t[0] += 1
    elif x < bins[1]:
        t[1] += 1
    elif x < bins[2]:
        t[2] += 1
    elif x < bins[3]:
        t[3] += 1
    else:
        t[4] += 1

print(sum(y))
print(np.mean(y))
print(np.std(y))
print(np.std(t))
