# -*- coding: utf-8 -*-
"""
Created on Mon Nov 21 16:47:31 2016

@author: danielle.leong
"""

max_points = [25, 25, 50, 25, 100]
assignments = ['hw ch 1', 'hw ch 2', 'hw ch 3', 'test']
students = {'#Max': max_points}

def print_menu():
    print("1. Add student")
    print("2. Remove student")
    print("3. Print grades")
    print("4. Record grade")
    print("5. Print menu")
    print("6. Exit")

def print_all_grades():
    print('\t', end = ' ')
        for i in range(len(assignments)):
            print(assignments[i], '\t', end = ' ')
        print()
        keys = list(students.keys())
        keys.sort()
        for x in keys:
            print(x, '\t', end = ' ')
            grades = students[x]
            print_grades(grades)

def print_grades(grades):
    for i in rang(len(grades)):
        print(grades[i], '\t', end = ' ')
    print()

print_menu()
menu_choice = 0
while menu_choice != 6:
    print()
    menu_choice = int(input("Menu choice (1-6): "))
    if menu_choice == 1:
        name = input("Student to add: ")
        students[name] = [0] * len(max_points)
    elif  menu_choice == 2:
        name = input("Student to remove: ")
        if name in students:
            del students[name]
        else:
            print("Student:", name,"not found")
    elif menu_choice == 3:
        print_all_grades()
    elif menu_choice == 4:
        print("Record grade")
        name = input("Student: ")
        if name in students:
            grades = students[name]
            print("Enter the number of the grade to record")
            print("Type in 0 to exit")
            for i in range(len(assignments)):
                print(i + 1, assignments[i], '\t', end = ' ')
            print()
            print_grades(grades)
            which = 1234
            while which != -1:
                which = int(input("Change which grade? "))
                which -= 1
                if 0 <= which < len(grades):
