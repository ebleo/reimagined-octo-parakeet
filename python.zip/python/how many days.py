# -*- coding: utf-8 -*-
"""
Created on Mon Nov 21 15:06:18 2016

@author: danielle.leong
"""

import datetime
print('How many days away?')

now = datetime.datetime.now()
y = int(input('Enter future year\t'))
m = int(input('Enter future month\t'))
d = int(input('Enter future day\t'))
print()

future = datetime.datetime(y, m, d)

diff = future - now

print("That day is ", str(diff), " days away.")

days = int(diff.days)

years = days//365 # rather than use floor(), use integer division [built in]
dyrem = days % 365
months = dyrem//30
dmrem = dyrem % 30

print("That's approximately ", years, " years, ", months, "months, and ", dmrem, "days.")
