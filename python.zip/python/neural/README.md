# neural
Building a neural network

Just a simple file holding the contents of my work with a neural network tutorial, found
HERE :
https://medium.com/technology-invention-and-more/how-to-build-a-simple-neural-network-in-9-lines-of-python-code-cc8f23647ca1#.37pd76lll
and also THERE:
http://iamtrask.github.io/2015/07/12/basic-python-network/
