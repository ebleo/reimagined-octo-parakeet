import numpy as np

# this is a sigmoid fxn and it's derivative
# assuming x is a sigmoid
def nonlin(x, deriv = False):
    if (deriv == True):
        return x * (1 - x)
    return 1 / (1 + np.exp(-x))

# data, inp
x = np.array([ [0,0,1],
            [0,1,1],
            [1,0,1],
            [1,1,1] ])

# data, outp
y = np.array([[0,0,1,1]]).T

# seeds rand nums to make calculation
# deterministic (just a good practice)
np.random.seed(1)

# init rand weights, mean = 0
syn0 = 2 * np.random.random((3, 1)) # basic math is always elementwise

for iter in xrange(10000):
    # fw propagation
    l0 = x
    l1 = nonlin(np.dot(l0, syn0)) # np.dot() for 2D arrary is MTX mult
