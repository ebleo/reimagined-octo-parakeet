# -*- coding: utf-8 -*-
"""
Created on Wed Dec 14 14:39:55 2016

@author: danielle.leong
"""

import pandas as pd
import numpy as np
import matplotlib as plt

df = pd.read_csv("train.csv") # file located in same dir as current .py file

print(df.head()) # view first few elements

print(df.describe()) # stat summary
# math stat info here: https://www.analyticsvidhya.com/blog/2014/07/statistics/

print(df.['Property_Area'].value_counts())
